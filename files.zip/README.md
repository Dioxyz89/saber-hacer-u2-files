# Docentes del Edificio 2 – UT Coahuila

API con FastAPI para administrar docentes (número de empleado, nombre y especialidad).
Cada alta, edición o baja se escribe **al mismo tiempo** en `data/docentes.json`,
`data/docentes.xml` y `data/docentes.yaml`.

## Instalación y ejecución

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

- Interfaz web: http://127.0.0.1:8000
- Documentación interactiva: http://127.0.0.1:8000/docs

## Endpoints

| Método | Ruta                        | Descripción                          |
|--------|-----------------------------|--------------------------------------|
| GET    | `/docentes`                 | Lista los docentes                   |
| GET    | `/docentes/{num_empleado}`  | Consulta un docente                  |
| POST   | `/docentes`                 | Registra un docente                  |
| PUT    | `/docentes/{num_empleado}`  | Actualiza nombre y especialidad      |
| DELETE | `/docentes/{num_empleado}`  | Elimina un docente                   |
| GET    | `/formatos/{json|xml|yaml}` | Ver el contenido actual de un archivo|
| GET    | `/exportar/zip`             | Descarga un .zip con los 3 formatos  |
