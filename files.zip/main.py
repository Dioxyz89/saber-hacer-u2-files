"""
Gestión de docentes del Edificio 2 - Universidad Tecnológica de Coahuila.

- CRUD completo con FastAPI.
- Cada cambio se escribe al mismo tiempo (en paralelo) en JSON, XML y YAML.
- Endpoint para descargar los tres formatos en un .zip.

Ejecutar:  uvicorn main:app --reload
Docs API:  http://127.0.0.1:8000/docs
"""
from __future__ import annotations

import io
import json
import os
import tempfile
import threading
import xml.etree.ElementTree as ET
import zipfile
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

import yaml
from fastapi import FastAPI, HTTPException, Response, status
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"

INSTITUCION = "Universidad Tecnológica de Coahuila"
EDIFICIO = 2

ARCHIVOS = {
    "json": "docentes.json",
    "xml": "docentes.xml",
    "yaml": "docentes.yaml",
}
MEDIA_TYPES = {
    "json": "application/json",
    "xml": "application/xml",
    "yaml": "text/yaml",
}


# --------------------------------------------------------------------------- #
# Modelos
# --------------------------------------------------------------------------- #
class DocenteActualizar(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)

    nombre: str = Field(..., min_length=3, max_length=120, examples=["María Fernanda López Ruiz"])
    especialidad: str = Field(..., min_length=2, max_length=120, examples=["Tecnologías de la Información"])


class DocenteCrear(DocenteActualizar):
    numero_empleado: str = Field(..., pattern=r"^[A-Za-z0-9\-]{1,20}$", examples=["UTC-1024"])


class Docente(DocenteCrear):
    pass


# --------------------------------------------------------------------------- #
# Almacén: memoria + escritura simultánea en 3 formatos
# --------------------------------------------------------------------------- #
class Almacen:
    def __init__(self, carpeta: Path) -> None:
        self.carpeta = carpeta
        self.carpeta.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.docentes: dict[str, dict] = {}

    # ---- carga inicial ---------------------------------------------------- #
    def cargar(self) -> None:
        ruta = self.carpeta / ARCHIVOS["json"]
        if ruta.exists():
            with ruta.open(encoding="utf-8") as f:
                contenido = json.load(f)
            self.docentes = {d["numero_empleado"]: d for d in contenido.get("docentes", [])}
        self.guardar_todo()  # asegura que los 3 archivos existan y estén sincronizados

    # ---- serializadores --------------------------------------------------- #
    def _lista(self) -> list[dict]:
        return [self.docentes[k] for k in sorted(self.docentes)]

    def _documento(self) -> dict:
        lista = self._lista()
        return {
            "institucion": INSTITUCION,
            "edificio": EDIFICIO,
            "actualizado": datetime.now().isoformat(timespec="seconds"),
            "total": len(lista),
            "docentes": lista,
        }

    @staticmethod
    def _a_json(doc: dict) -> str:
        return json.dumps(doc, ensure_ascii=False, indent=2) + "\n"

    @staticmethod
    def _a_yaml(doc: dict) -> str:
        return yaml.safe_dump(doc, allow_unicode=True, sort_keys=False, default_flow_style=False)

    @staticmethod
    def _a_xml(doc: dict) -> str:
        raiz = ET.Element(
            "docentes",
            institucion=doc["institucion"],
            edificio=str(doc["edificio"]),
            actualizado=doc["actualizado"],
            total=str(doc["total"]),
        )
        for d in doc["docentes"]:
            nodo = ET.SubElement(raiz, "docente")
            for campo in ("numero_empleado", "nombre", "especialidad"):
                ET.SubElement(nodo, campo).text = d[campo]
        ET.indent(raiz, space="  ")
        return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(raiz, encoding="unicode") + "\n"

    def contenidos(self) -> dict[str, str]:
        """Genera el texto de los tres formatos a partir del estado actual."""
        doc = self._documento()
        return {
            "json": self._a_json(doc),
            "xml": self._a_xml(doc),
            "yaml": self._a_yaml(doc),
        }

    # ---- escritura -------------------------------------------------------- #
    def _escribir_atomico(self, formato: str, texto: str) -> None:
        destino = self.carpeta / ARCHIVOS[formato]
        fd, tmp = tempfile.mkstemp(dir=self.carpeta, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(texto)
            os.replace(tmp, destino)
        except BaseException:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise

    def guardar_todo(self) -> None:
        """Escribe JSON, XML y YAML al mismo tiempo (un hilo por formato)."""
        textos = self.contenidos()
        with ThreadPoolExecutor(max_workers=3) as pool:
            tareas = [pool.submit(self._escribir_atomico, fmt, txt) for fmt, txt in textos.items()]
            for t in tareas:
                t.result()  # propaga cualquier error de escritura

    def _confirmar(self, previo: dict[str, dict]) -> None:
        """Persiste; si falla, revierte la memoria para no quedar desincronizados."""
        try:
            self.guardar_todo()
        except OSError as exc:
            self.docentes = previo
            raise HTTPException(
                status.HTTP_500_INTERNAL_SERVER_ERROR,
                f"No se pudieron guardar los archivos: {exc}",
            ) from exc

    # ---- operaciones CRUD ------------------------------------------------- #
    def listar(self) -> list[dict]:
        with self.lock:
            return self._lista()

    def obtener(self, numero: str) -> dict:
        with self.lock:
            if numero not in self.docentes:
                raise HTTPException(404, f"No existe el docente con número de empleado '{numero}'.")
            return self.docentes[numero]

    def crear(self, datos: DocenteCrear) -> dict:
        with self.lock:
            if datos.numero_empleado in self.docentes:
                raise HTTPException(409, f"Ya existe el número de empleado '{datos.numero_empleado}'.")
            previo = dict(self.docentes)
            self.docentes[datos.numero_empleado] = datos.model_dump()
            self._confirmar(previo)
            return self.docentes[datos.numero_empleado]

    def actualizar(self, numero: str, datos: DocenteActualizar) -> dict:
        with self.lock:
            if numero not in self.docentes:
                raise HTTPException(404, f"No existe el docente con número de empleado '{numero}'.")
            previo = dict(self.docentes)
            self.docentes[numero] = {"numero_empleado": numero, **datos.model_dump()}
            self._confirmar(previo)
            return self.docentes[numero]

    def eliminar(self, numero: str) -> None:
        with self.lock:
            if numero not in self.docentes:
                raise HTTPException(404, f"No existe el docente con número de empleado '{numero}'.")
            previo = dict(self.docentes)
            del self.docentes[numero]
            self._confirmar(previo)

    # ---- exportación ------------------------------------------------------ #
    def zip_bytes(self) -> bytes:
        with self.lock:
            textos = self.contenidos()
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            for fmt, texto in textos.items():
                zf.writestr(ARCHIVOS[fmt], texto.encode("utf-8"))
        return buffer.getvalue()


almacen = Almacen(DATA_DIR)


# --------------------------------------------------------------------------- #
# Aplicación
# --------------------------------------------------------------------------- #
@asynccontextmanager
async def lifespan(_: FastAPI):
    almacen.cargar()
    yield


app = FastAPI(
    title="Docentes del Edificio 2 - UT Coahuila",
    description="CRUD de docentes con persistencia simultánea en XML, JSON y YAML.",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/", include_in_schema=False)
def inicio() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/docentes", response_model=list[Docente], tags=["CRUD"])
def listar_docentes():
    return almacen.listar()


@app.get("/docentes/{numero_empleado}", response_model=Docente, tags=["CRUD"])
def obtener_docente(numero_empleado: str):
    return almacen.obtener(numero_empleado)


@app.post("/docentes", response_model=Docente, status_code=status.HTTP_201_CREATED, tags=["CRUD"])
def crear_docente(docente: DocenteCrear):
    return almacen.crear(docente)


@app.put("/docentes/{numero_empleado}", response_model=Docente, tags=["CRUD"])
def actualizar_docente(numero_empleado: str, docente: DocenteActualizar):
    return almacen.actualizar(numero_empleado, docente)


@app.delete("/docentes/{numero_empleado}", status_code=status.HTTP_204_NO_CONTENT, tags=["CRUD"])
def eliminar_docente(numero_empleado: str):
    almacen.eliminar(numero_empleado)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@app.get("/formatos/{formato}", tags=["Formatos"])
def ver_formato(formato: str):
    """Devuelve el contenido actual de uno de los archivos (json, xml o yaml)."""
    if formato not in ARCHIVOS:
        raise HTTPException(404, "Formato no válido. Usa: json, xml o yaml.")
    with almacen.lock:
        texto = almacen.contenidos()[formato]
    return Response(content=texto, media_type=f"{MEDIA_TYPES[formato]}; charset=utf-8")


@app.get("/exportar/zip", tags=["Formatos"])
def exportar_zip():
    """Descarga un .zip con docentes.json, docentes.xml y docentes.yaml."""
    nombre = f"docentes_edificio2_{datetime.now():%Y%m%d_%H%M%S}.zip"
    return StreamingResponse(
        io.BytesIO(almacen.zip_bytes()),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{nombre}"'},
    )


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
